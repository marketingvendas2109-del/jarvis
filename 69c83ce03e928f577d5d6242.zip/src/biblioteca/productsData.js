const gd = (id) => `https://lh3.googleusercontent.com/d/${id}`;

export const products = [
  // KITS FIRST
  {
    id: "camisa-brasil-2026",
    name: "Camisa Brasil 2026",
    price: 85.00,
    category: "Camisas",
    images: [gd("1NJsEwYjXk15DFraCcDv5BO0fLEYsYUhG"), gd("1-iqzIspHCV52FCEEcyqFLTm7KktiW8AF")],
    freeShipping: true,
    description: `A Camisa Brasil 2026 não é apenas uma peça de roupa, é uma celebração da nossa cultura e do nosso espírito guerreiro. Com símbolos bordados que representam o orgulho e a força do nosso país, essa camisa é ideal para aqueles momentos em que você quer se destacar, seja em um evento, numa festa ou simplesmente na sua rotina do dia a dia. Com um tecido leve e arejado que proporciona um fit incrível, você vai sentir o conforto e a liberdade de movimentos com cada passo.

Feita para o homem moderno que valoriza o estilo sem abrir mão do conforto, a Camisa Brasil 2026 permite que você expresse sua identidade de forma elegante. Use-a com os amigos, em um churrasco ou até mesmo nas arquibancadas assistindo ao seu time do coração. Sinta-se confiante, autêntico e pronto para viver experiências memoráveis, tudo isso enquanto exibe uma moda que fala diretamente ao seu coração. Não perca a chance de fazer parte desta história!`,
  },
  {
    id: "kit-mizuno-preto",
    name: "Kit Mizuno preto",
    price: 85.00,
    category: "Kits",
    images: [gd("1JmsGVCSc0v0atfGYD3uF-UWPkzlXwi4i")],
    freeShipping: true,
    description: "Kit Mizuno preto completo. Estilo esportivo no máximo.",
  },
  {
    id: "kit-lacoste-vermelho",
    name: "Kit Lacoste vermelho",
    price: 85.00,
    category: "Kits",
    images: [gd("1tiWUjAZeYhS-3T2HmtfbEoxVSHnpLBaI")],
    freeShipping: true,
    description: "Kit Lacoste vermelho. Elegância e atitude em um só look.",
  },
  {