# Apple Product Gallery Design Skill

This package contains a reusable `SKILL.md` derived from the provided `DESIGN.md`.

## Install / reuse
- Copy `SKILL.md` into the skill directory supported by your AI coding assistant.
- If the assistant uses a `skills/` folder, place it at `skills/apple-product-gallery-design-system/SKILL.md`.
- For a project-specific workflow, keep the skill file available to the agent and explicitly invoke it before implementation/review.
- The skill defines a mandatory workflow and visual quality gate. An instruction file cannot technically override higher-priority platform/system policies, but it tells the agent to apply these rules whenever the skill is in scope.

The source DESIGN.md is not required at runtime because the skill includes the visual tokens, component rules, layout guidance, prohibitions, and audit checklist.

## Files in this folder
- `SKILL.md` — the full design-system skill (rules, tokens, components, QA checklist).
- `tokens.css` — the shared CSS token source from SKILL.md §10.