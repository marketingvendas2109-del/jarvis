# Como usar a Skill

## 1. Importar os tokens

No `index.css` do projeto, adicione no topo (antes do `@tailwind base`):

```css
@import './lib/design-system/tokens.css';
```

## 2. Usar os componentes

```jsx
import {
  PillButton,
  ProductCard,
  CategoryHeroCard,
  EditorialHero,
  TopNav,
  FooterGrid,
  SearchField
} from "@/components/design-system";
```

## 3. Seguir o SKILL.md

O arquivo `src/lib/design-system/SKILL.md` contém todas as regras visuais obrigatórias.
**Toda nova tela deve passar pelo checklist de validação** no final do SKILL.md.

## Resumo das regras

- ✅ Apenas 6 cores: Obsidian, Paper White, Concrete Gray, Soft Mist, Steel, Faint Gray
- ✅ Apenas pesos 400 e 500 (nunca bold)
- ✅ Botões: 30px radius (pill), sem sombra