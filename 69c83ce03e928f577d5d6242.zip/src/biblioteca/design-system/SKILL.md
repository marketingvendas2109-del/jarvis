# SKILL — Nike.com Monochrome Gallery Design System

> **Esta Skill obriga a IA a seguir TODAS as regras visuais abaixo em qualquer projeto.**
> Quando esta Skill está ativa, nenhuma regra visual pode ser violada — sem exceção.

---

## 🎯 PRINCÍPIO FUNDAMENTAL

A interface é uma **galeria monocromática**. O UI fica quase invisível para que a **fotografia do produto** carregue cada tela. Toda a interface é construída com **preto, branco e três tons de cinza** — sem cor de destaque, sem gradiente decorativo, sem cromagem de marca. A identidade vive no logotipo e na fotografia, **nunca no UI em si**.

---

## 🚫 REGRA DE OURO — O QUE NUNCA FAZER

1. **NUNCA introduzir cor de destaque no UI.** Sem azul, vermelho, verde ou amarelo em botões, links, badges ou ícones. A única cor na interface vem da fotografia do produto.
2. **NUNCA usar pesos bold ou semibold.** O sistema tipográfico é exclusivamente **400 e 500**.
3. **NUNCA adicionar box-shadow** em cards, botões ou navegação. Elevação = alternância claro/escuro, não sombra.
4. **NUNCA arredondar cantos de cards.** Cards são tiles sharp-edged full-bleed. Apenas botões (30px), search (24px) e utility bar (24px) são arredondados.
5. **NUNCA usar mais de um tratamento de CTA por página.** Pill button é sempre Obsidian-on-white ou white-on-Obsidian — nunca uma terceira variante.
6. **NUNCA adicionar gradientes decorativos, padrões ou imagens de fundo atrás de texto.** Cada seção é ou branco puro ou foto full-bleed.
7. **NUNCA usar tipografia display abaixo de 20px ou acima de 76px.** Futura ND vive apenas em escala hero.
8. **NUNCA preencher a nav com background.** Nav é transparente sobre branco — sem fill, sem shadow, sem sticky blur.

---

## 🎨 PALETA — USAR APENAS ESTAS CORES

| Token | Valor | Uso |
|-------|-------|-----|
| `--color-obsidian` | `#111111` | Texto, ícones, contraste forte, fill de botão primário |
| `--color-paper-white` | `#ffffff` | Fundo de página, superfície de card, texto sobre dark fills |
| `--color-concrete-gray` | `#e5e5e5` | Bordas, divisores, hairline separators |
| `--color-soft-mist` | `#f5f5f5` | Tint de superfície secundária, fill do search, fundo de tags |
| `--color-steel` | `#707072` | Texto secundário, copy muted, outlines de ícones pequenos |
| `--color-faint-gray` | `#9e9ea0` | Ícones disabled, bordas de menor ênfase |

**Nenhuma outra cor é permitida no UI.** Ponto final.

---

## 📝 TIPOGRAFIA

### Famílias (substitutos permitidos)

| Token | Família | Substituto | Pesos |
|-------|--------|-----------|-------|
| `--font-helvetica-now-text` | Helvetica Now Text | **Inter** ou Helvetica Neue | 400, 500 |
| `--font-helvetica-now-display-medium` | Helvetica Now Display Medium | **Inter Medium** ou Helvetica Neue Medium | 500 |
| `--font-nike-futura-nd` | Nike Futura ND | **Futura PT Medium** | 500 |

### Escala Tipográfica

| Role | Tamanho | Line-height | Letter-spacing | Família |
|------|---------|-------------|----------------|---------|
| caption | 12px | 1.5 | 0px | Helvetica Now Text |
| body-sm | 14px | 1.75 | 0px | Helvetica Now Text |
| body | 16px | 1.75 | 0px | Helvetica Now Text |
| subheading | 20px | 1.5 | 0px | Helvetica Now Display Medium |
| heading-sm | 24px | 1.2 | 0px | Helvetica Now Display Medium |
| display | 76px | 1.0 | 0px | Nike Futura ND |

**Regras:**
- Nav links, button labels, product names → Helvetica Now Text Medium 16px
- Section headings, category labels → Helvetica Now Display Medium 20-24px (nunca bold)
- Hero headlines → Nike Futura ND 76px, line-height **travada em 1.0**
- Body text nunca acima de 20px nem abaixo de 12px

---

## 📐 ESPAÇAMENTO & FORMAS

**Unidade base:** 4px · **Densidade:** compact

### Spacing Scale
`4px · 8px · 12px · 16px · 20px · 24px · 36px · 48px`

### Border Radius

| Elemento | Raio |
|----------|------|
| Botões | **30px** (pill completo) |
| Search field | 24px |
| Utility bar (nav) | 24px |
| Tags | 30px |
| Cards | **0px** (sharp-edged) |
| Inputs | 0px |

### Layout
- **Page max-width:** 1440px (aplica-se apenas a nav e footer)
- **Section gap:** 48px
- **Card padding:** 12px
- **Element gap:** 8px
- Conteúdo de seção (hero, category grid) → **full-bleed**, sem max-width

---

## 🧩 COMPONENTES — ESPECIFICAÇÃO OBRIGATÓRIA

### 1. Pill Button (Primary)
- Fill: Obsidian `#111111` · Texto: Paper White `#ffffff`
- Font: Helvetica Now Text Medium 16px/1.5
- Border-radius: **30px** (pill)
- Padding: 6px vertical / 8px horizontal
- **Sem borda, sem sombra, sem hover decoration** (apenas opacity)
- Variante inversa: white fill + Obsidian text (para uso sobre dark heroes)

### 2. Category Hero Card
- **Sem borda, sem raio, sem sombra**
- Fotografia preenche edge-to-edge (full-bleed)
- Texto overlaid bottom-left em branco:
  - Label de categoria: Helvetica Now Text 16px
  - Headline: Helvetica Now Display Medium 20-24px
- Pill buttons (white fill, Obsidian text) abaixo da headline

### 3. Product Card
- Fundo branco, **sem borda, sem raio, sem sombra**
- Imagem do produto centralizada na porção superior
- Nome do produto como **pill pequeno** (Obsidian fill, white text, 30px radius, Helvetica Now Text Medium 12-16px)
- **Sem preço, sem descrição, sem CTAs dentro do card**

### 4. Top Navigation Bar
- **Dois níveis:**
  - Utility bar fina (search, help, login) — Helvetica Now Text 12px Obsidian sobre branco
  - Main nav row — logo à esquerda, links de categoria ao centro (Helvetica Now Text Medium 16px), search + wishlist + bag à direita
- Search field: `#f5f5f5` com 24px radius
- **Sem background fill, sem shadow, sem sticky blur** — senta direto sobre branco

### 5. Editorial Hero Section
- Full-bleed background near-black `#111111` ou gradiente dark
- Produto fotografado grande, centralizado ou three-quarter
- Headline: Nike Futura ND **76px** branco, line-height **1.0**, posicionado bottom-left
- Sub-copy: Helvetica Now Text 16px branco abaixo
- Único CTA: pill button white fill + Obsidian text
- **Sem elementos decorativos, sem indicadores de carrossel visíveis**

### 6. Footer Link Grid
- Fundo branco
- Quatro colunas (Recursos, Ajuda, Empresa, Descontos)
- Headers: Helvetica Now Display Medium 16-20px Obsidian
- Links: Helvetica Now Text 16px Steel `#707072`, row-gap 12px
- Region selector à direita no header row
- **Sem divisores, sem background fills, sem social icons**

### 7. Search Field
- Background: `#f5f5f5` (Soft Mist)
- Border-radius: 24px
- **Sem borda**
- Placeholder: Helvetica Now Text 16px Obsidian
- Search icon: Steel `#707072` alinhado à esquerda
- Padding: 6px vertical / 8px horizontal

### 8. Icon System
- Stroke-based outlined, 1.5-2px stroke
- Default: Obsidian `#111111`
- Secondary: Steel `#707072`
- **Sem variantes filled, sem ícones multicolor**
- Tamanho: 16-20px

---

## 🏗️ ESTRUTURA DE PÁGINA

```
[Dark Hero — full viewport, 76px headline]
    ↓ stark transition
[2x2 Category Grid — full-bleed tiles, sem gap]
    ↓ hairline border
[3-column Product Grid — white, sharp cards]
    ↓
[Footer Link Grid — 4 columns, white]
```

- **Transições são stark:** black hero → white grid → white footer
- **Concrete Gray hairline borders** são a única costura visual entre seções
- Nav e footer respeitam 1440px max-width; hero e category grid são full-bleed

---

## 📸 IMAGEM

- Fotografia high-res, full-bleed, produto em isolamento
- Sem contexto lifestyle nos product cards; lifestyle apenas em category tiles
- Tratamento high-contrast e color-saturated — a cor vem DA FOTO, não do UI
- **Sem ilustração, sem gráficos abstratos, sem 3D renders**
- Containers de foto: **sempre sharp-edged** (sem radius), sempre full-bleed

---

## ✅ CHECKLIST DE VALIDAÇÃO (antes de entregar)

- [ ] Zero cores de destaque no UI (apenas Obsidian, White, Concrete, Soft Mist, Steel, Faint)
- [ ] Zero box-shadows em qualquer elemento
- [ ] Cards têm border-radius: 0px
- [ ] Botões têm border-radius: 30px (pill)
- [ ] Search field tem border-radius: 24px
- [ ] Pesos tipográficos são apenas 400 e 500 (zero bold/semibold)
- [ ] Hero headline é 76px com line-height 1.0
- [ ] Nav é transparente sobre branco (sem fill, sem shadow)
- [ ] Apenas um tratamento de CTA por página
- [ ] Seções alternam entre branco puro e dark full-bleed
- [ ] Divisores são Concrete Gray hairlines, nunca sombras

---

## 🔧 APLICAÇÃO

1. Importar `tokens.css` no `index.css` do projeto
2. Usar os componentes de `src/components/design-system/`
3. Toda nova tela deve passar pelo checklist de validação acima
4. **Esta Skill tem prioridade sobre qualquer preferência de design anterior**