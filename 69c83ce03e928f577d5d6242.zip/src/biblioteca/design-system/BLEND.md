# ZENON — Design System Blend

Two systems govern this project's visuals. Where they conflict, the blend below wins.

- **Nike.com Monochrome Gallery** (`./SKILL.md`) — brand restraint: monochrome UI, product-led photography, zero accent decoration, no shadows.
- **Apple Product Gallery** (`./apple-product-gallery/SKILL.md`) — premium structure: rounded media, soft neutral scale, generous editorial spacing, refined type.

## The blend (what wins where)

| Decision | Nike | Apple | Blend (used) |
|---|---|---|---|
| Canvas | `#ffffff` | `#ffffff` | `#ffffff` |
| Ink / primary text | `#111111` | `#1d1d1f` | **`#1d1d1f`** |
| Secondary text | `#707072` | `#707070` | **`#707070`** |
| Bands / media backdrop | `#f5f5f5` | `#f5f5f7` | **`#f5f5f7`** |
| Hairline | `#e5e5e5` | `#e6e6e8` | **`#e6e6e8`** |
| Cards / media radius | 0px (sharp) | 28px | **28px** |
| Buttons | 30px pill | 9999px pill | **9999px pill** |
| Accent color | none | `#0066cc` / `#0071e3` | **`#0066cc` for inline text links only** |
| Shadows | none | none | **none** |
| Gradients | none | none | **none** |
| Weights | 400 / 500 | 400 / 500 / 600 | **400 / 500 / 600** |
| Display headings | Futura 76px/1.0 | SF Pro Display 80px/600 | **Inter 600, tight tracking, 32–72px** |
| Section rhythm | 48px gaps, compact | ~90px, spacious | **~80px spacious, editorial** |

## Documented exceptions (skill §9 allows explaining these)

1. **Monochrome-first palette.** The client is a clothing brand whose identity is monochrome. The Apple blue is used *only* for inline text links (e.g. "Ver tudo"), never as a primary CTA. Primary conversion buttons stay ink (`#1d1d1f`) — see the Nike rule "one CTA treatment per page".
2. **Inter as the font.** `SF Pro` is not licensed for web bundling, so the Apple fallback stack (`Inter`, `Helvetica Neue`, `Arial`) is used. Weights are limited to 400 / 500 / 600; 700 is never used.
3. **Radii below 28px are not used for media.** 28px is applied to cards and media frames; pill controls use full radius.

## Where the tokens live

- Single shared source: `src/lib/design-system/tokens.css` (imported by `src/index.css`).