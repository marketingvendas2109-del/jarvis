// Gerador de Payload PIX (padrão EMV - BR.GOV.BCB.PIX)
// CRC16/CCITT-FALSE (poly 0x1021, init 0xFFFF)

function crc16(str) {
  let crc = 0xFFFF;
  const buf = new TextEncoder().encode(str);
  for (let i = 0; i < buf.length; i++) {
    crc ^= buf[i] << 8;
    for (let j = 0; j < 8; j++) {
      crc = (crc & 0x8000) ? ((crc << 1) ^ 0x1021) : (crc << 1);
    }
  }
  return (crc & 0xFFFF).toString(16).toUpperCase().padStart(4, '0');
}

function field(id, value) {
  const len = value.length.toString().padStart(2, '0');
  return `${id}${len}${value}`;
}

export function generatePixPayload({ key, name, city, amount, txid = '***' }) {
  // Merchant Account Information (GUI + key)
  const gui = field('00', 'BR.GOV.BCB.PIX');
  const keyField = field('01', key);
  const merchantInfo = field('26', gui + keyField);

  // Additional Data (txid)
  const additionalData = field('62', field('05', txid.substring(0, 25)));

  // Amount formatted
  const amountStr = parseFloat(amount).toFixed(2);

  // Name max 25 chars, City max 15 chars
  const nameClean = name.substring(0, 25).toUpperCase();