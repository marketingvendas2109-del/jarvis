/**
 * Converte qualquer link do Google Drive para URL de exibição direta.
 * Se não for Drive, retorna o link original.
 */
export function resolveImageUrl(url) {
  if (!url) return "";

  // Formato: /file/d/FILE_ID/view ou /file/d/FILE_ID
  const matchFile = url.match(/\/file\/d\/([a-zA-Z0-9_-]+)/);
  if (matchFile) {
    return `https://lh3.googleusercontent.com/d/${matchFile[1]}`;
  }

  // Formato: id=FILE_ID (ex: drive.google.com/uc?id=...)
  const matchId = url.match(/[?&]id=([a-zA-Z0-9_-]+)/);
  if (matchId) {
    return `https://lh3.googleusercontent.com/d/${matchId[1]}`;
  }

  // Já está no formato lh3 ou outro link direto
  return url;
}