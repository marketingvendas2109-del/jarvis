import { useState } from "react";
import { Send, CheckCircle } from "lucide-react";

export default function Contact() {
  const [form, setForm] = useState({ name: "", email: "", phone: "", message: "" });
  const [sent, setSent] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    await new Promise(r => setTimeout(r, 1000));
    setLoading(false);
    setSent(true);
  };

  return (
    <div className="bg-black min-h-screen">
      <div className="max-w-2xl mx-auto px-4 py-16">
        {/* Breadcrumb */}
        <p className="text-white/40 text-xs mb-6">Início &rsaquo; Contato</p>

        <h1 className="text-white font-bold text-3xl mb-10 text-center">Contato</h1>

        {sent ? (
          <div className="text-center py-16">
            <CheckCircle size={64} className="text-green-400 mx-auto mb-4" />
            <h2 className="text-white font-bold text-2xl mb-2">Mensagem enviada!</h2>
            <p className="text-white/50">Entraremos em contato em breve.</p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="flex flex-col gap-5">
            <div>
              <label className="text-white/70 text-sm mb-2 block">Nome</label>