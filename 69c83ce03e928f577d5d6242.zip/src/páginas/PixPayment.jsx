import { useState } from "react";
import { useLocation, Link, useNavigate } from "react-router-dom";
import {
  Copy, CheckCheck, ArrowLeft, CheckCircle,
  ShoppingBag, MessageCircle, CreditCard, ChevronDown, ChevronUp
} from "lucide-react";

import { format, addDays } from "date-fns";

const PIX_KEY = "81996827464";
const PIX_NAME = "Gilvonete Ilario da Silva Santos";
const WHATSAPP_NUMBER = "5581996827464";

function gerarParcelas(total, num, hoje = new Date()) {
  const valor = total / num;
  return Array.from({ length: num }, (_, i) => {
    const data = addDays(hoje, 30 * (i + 1));
    return {
      numero: i + 1,
      valor: parseFloat(valor.toFixed(2)),
      data: format(data, "dd/MM/yyyy"),
      dataISO: data.toISOString(),
      paga: false,
    };
  });
}

export default function PixPayment() {
  const location = useLocation();
  const navigate = useNavigate();
  const { items = [], total = 0 } = location.state || {};

  const [modo, setModo] = useState("pix"); // "pix" | "parcelado"
  const [copied, setCopied] = useState(false);