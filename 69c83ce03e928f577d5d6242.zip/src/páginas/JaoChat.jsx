const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";

import { ArrowLeft, Send, Loader2, Search } from "lucide-react";
import { motion } from "framer-motion";
import ReactMarkdown from "react-markdown";
import PageTransition from "@/components/PageTransition";

const GREETING =
  "E aí mano! 👊 Sou o Jão, da ZENON. Tô aqui pra te ajudar a montar o look perfeito. Quer dar uma olhada nos kits dry fit ou tem algo específico em mente?";

function ToolCallBadge({ toolCall }) {
  const status = toolCall?.status || "";
  const isRunning = ["pending", "running", "in_progress"].includes(status);
  const isDone = ["completed", "success"].includes(status);
  const failed = ["failed", "error"].includes(status);

  return (
    <div className="mt-2 flex items-center gap-1.5 text-[11px] text-white/40 border-t border-white/10 pt-2">
      {isRunning ? <Loader2 size={11} className="animate-spin" /> : <Search size={11} />}
      <span>
        {failed ? "Erro ao buscar produtos" : isRunning ? "Consultando catálogo..." : "Produtos verificados ✅"}
      </span>
    </div>
  );
}

export default function JaoChat() {
  const navigate = useNavigate();
  const [conversationId, setConversationId] = useState(null);
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const endRef = useRef(null);

  useEffect(() => {
    let unsubscribe = null;
    const init = async () => {
      try {
        let conv = null;
        const existing = await db.agents.listConversations({ agent_name: "jao_vendedor" });
        if (existing && existing.length > 0) {
          conv = existing[0];
        } else {
          conv = await db.agents.createConversation({
            agent_name: "jao_vendedor",
            metadata: { name: "Chat com Jão", description: "Conversa com o vendedor" },
          });
        }
        if (conv) {
          setConversationId(conv.id);
          const full = await db.agents.getConversation(conv.id);
          if (full?.messages?.length > 0) {
            setMessages(full.messages);
          } else {
            setMessages([{ role: "assistant", content: GREETING }]);
          }
          unsubscribe = db.agents.subscribeToConversation(conv.id, (data) => {
            if (data?.messages) setMessages(data.messages);
            setSending(false);
          });
        }
      } catch {
        setMessages([
          { role: "assistant", content: "Ei, deu um rolê pra carregar o chat 😅 Tenta recarregar a página aí mano." },
        ]);
      } finally {
        setLoading(false);
      }
    };
    init();
    return () => {
      if (unsubscribe) unsubscribe();
    };
  }, []);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, sending]);

  const handleSend = async () => {
    if (!input.trim() || !conversationId || sending) return;
    const content = input.trim();
    setInput("");
    setSending(true);
    try {
      const conv = await db.agents.getConversation(conversationId);
      await db.agents.addMessage(conv, { role: "user", content });
    } catch {
      setSending(false);
    }
  };

  if (loading) {
    return (
      <div className="bg-black min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-white/40 animate-spin" />
      </div>
    );
  }

  return (
    <PageTransition>
      <div className="bg-black min-h-screen flex flex-col">
        {/* Header */}
        <div className="border-b border-white/10 px-4 py-3 flex items-center gap-3 sticky top-0 bg-black z-10">
          <button onClick={() => navigate(-1)} className="text-white/60 hover:text-white transition-colors">
            <ArrowLeft size={20} />
          </button>
          <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-blue-700 rounded-full flex items-center justify-center text-white font-black text-base">
            J
          </div>
          <div>
            <p className="text-white font-bold text-sm">Jão</p>
            <p className="text-green-400 text-xs flex items-center gap-1">
              <span className="w-1.5 h-1.5 bg-green-400 rounded-full" /> online
            </p>
          </div>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto px-4 py-6 space-y-4 max-w-2xl mx-auto w-full">
          {messages.map((msg, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}
            >
              <div
                className={`max-w-[80%] rounded-2xl px-4 py-2.5 ${
                  msg.role === "user"
                    ? "bg-white text-black rounded-br-sm"
                    : "bg-zinc-900 text-white border border-white/10 rounded-bl-sm"
                }`}
              >
                {msg.role === "user" ? (
                  <p className="text-sm leading-relaxed">{msg.content}</p>
                ) : (
                  <div className="text-sm leading-relaxed [&_p]:my-0.5 [&_ul]:my-1 [&_li]:my-0.5">
                    <ReactMarkdown>{msg.content || ""}</ReactMarkdown>
                  </div>
                )}
                {msg.tool_calls?.map((tc, j) => (
                  <ToolCallBadge key={j} toolCall={tc} />
                ))}
              </div>
            </motion.div>
          ))}
          {sending && (
            <div className="flex justify-start">
              <div className="bg-zinc-900 border border-white/10 rounded-2xl rounded-bl-sm px-4 py-3">
                <div className="flex gap-1">
                  <span className="w-2 h-2 bg-white/40 rounded-full animate-bounce" style={{ animationDelay: "0ms" }} />
                  <span className="w-2 h-2 bg-white/40 rounded-full animate-bounce" style={{ animationDelay: "150ms" }} />
                  <span className="w-2 h-2 bg-white/40 rounded-full animate-bounce" style={{ animationDelay: "300ms" }} />
                </div>
              </div>
            </div>
          )}
          <div ref={endRef} />
        </div>

        {/* Input */}
        <div className="border-t border-white/10 px-4 py-3 sticky bottom-0 bg-black">
          <div className="max-w-2xl mx-auto flex gap-2">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleSend()}
              placeholder="Manda tua mensagem pro Jão..."
              className="flex-1 bg-white/10 text-white placeholder-white/30 rounded-xl px-4 py-3 text-sm outline-none border border-white/10 focus:border-white/30 transition-colors"
            />
            <button
              onClick={handleSend}
              disabled={!input.trim() || sending}
              className="bg-white text-black p-3 rounded-xl hover:bg-white/90 transition-colors disabled:opacity-30 flex items-center justify-center"
            >
              <Send size={18} />
            </button>
          </div>
        </div>
      </div>
    </PageTransition>
  );
}