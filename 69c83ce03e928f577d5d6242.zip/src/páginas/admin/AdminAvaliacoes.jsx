import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { ArrowLeft, Plus, Trash2, Star, X, Check, Eye, EyeOff } from "lucide-react";

import AdminGate from "../../components/AdminGate";

function StarPicker({ nota, onChange }) {
  const [hover, setHover] = useState(0);
  return (
    <div className="flex gap-1">
      {[1, 2, 3, 4, 5].map(i => (
        <button
          key={i}
          type="button"
          onMouseEnter={() => setHover(i)}
          onMouseLeave={() => setHover(0)}
          onClick={() => onChange(i)}
          className="transition-transform hover:scale-110"
        >
          <Star
            size={24}
            strokeWidth={1.5}
            className={(hover || nota) >= i ? "text-[#111111] fill-[#111111]" : "text-[#e5e5e5]"}
          />
        </button>
      ))}
    </div>
  );
}

const inputClass = "w-full bg-[#f5f5f5] text-[#111111] placeholder-[#9e9ea0] rounded-none px-4 py-3 text-sm outline-none focus:bg-[#ebebeb] border border-[#e5e5e5]";

export default function AdminAvaliacoes() {
  const [avaliacoes, setAvaliacoes] = useState([]);