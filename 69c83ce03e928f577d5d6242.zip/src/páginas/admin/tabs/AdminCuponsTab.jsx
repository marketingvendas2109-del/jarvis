const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState, useEffect } from "react";
import { Plus, X, Check, Trash2, Pencil } from "lucide-react";

export default function AdminCuponsTab() {
  const [cupons, setCupons] = useState([]);
  const [produtos, setProdutos] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [salvando, setSalvando] = useState(false);
  const [editandoId, setEditandoId] = useState(null);
  const [editForm, setEditForm] = useState({});
  const [form, setForm] = useState({ codigo: "", desconto_reais: "", produto_id: "" });

  useEffect(() => {
    Promise.all([
      db.entities.Cupom.list(),
      db.entities.Produto.list("-created_date", 200),
    ]).then(([c, p]) => {
      setCupons(c);
      setProdutos(p);
      setLoading(false);
    });
  }, []);

  const handleSalvar = async () => {
    if (!form.codigo || !form.desconto_reais) return alert("Preencha código e desconto.");
    setSalvando(true);
    const novo = await db.entities.Cupom.create({
      codigo: form.codigo.toUpperCase().trim(),
      desconto_reais: parseFloat(form.desconto_reais),
      produto_id: form.produto_id || "",
    });
    setCupons(prev => [novo, ...prev]);
    setForm({ codigo: "", desconto_reais: "", produto_id: "" });
    setShowForm(false);
    setSalvando(false);
  };

  const handleDelete = async (id) => {
    if (!confirm("Remover este cupom?")) return;
    await db.entities.Cupom.delete(id);
    setCupons(prev => prev.filter(c => c.id !== id));
  };

  const iniciarEdicao = (c) => {
    setEditandoId(c.id);
    setEditForm({ codigo: c.codigo, desconto_reais: c.desconto_reais, produto_id: c.produto_id || "" });
  };

  const salvarEdicao = async (id) => {
    await db.entities.Cupom.update(id, {
      codigo: editForm.codigo.toUpperCase().trim(),
      desconto_reais: parseFloat(editForm.desconto_reais),
      produto_id: editForm.produto_id || "",
    });
    setCupons(prev => prev.map(c => c.id === id ? { ...c, ...editForm, codigo: editForm.codigo.toUpperCase().trim(), desconto_reais: parseFloat(editForm.desconto_reais) } : c));
    setEditandoId(null);
    setEditForm({});
  };

  const getProdutoNome = (id) => {
    if (!id) return "🌐 Todos os produtos";
    const p = produtos.find(p => p.id === id);
    return p ? p.nome : "Produto não encontrado";
  };

  if (loading) return (
    <div className="flex items-center justify-center py-20">
      <div className="w-8 h-8 border-4 border-white/20 border-t-white rounded-full animate-spin" />
    </div>
  );

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <p className="text-white/40 text-sm">{cupons.length} cupom(ns)</p>
        <button
          onClick={() => setShowForm(!showForm)}
          className="flex items-center gap-2 bg-white text-black font-bold px-5 py-2.5 rounded-xl text-sm hover:bg-white/90 transition-colors"
        >
          {showForm ? <X size={15} /> : <Plus size={15} />}
          {showForm ? "Cancelar" : "Novo cupom"}
        </button>
      </div>

      {showForm && (
        <div className="bg-zinc-900 rounded-2xl border border-white/10 p-6 mb-6">
          <p className="text-white font-bold mb-4">Criar cupom</p>
          <CupomForm form={form} setForm={setForm} produtos={produtos} />
          <button onClick={handleSalvar} disabled={salvando} className="mt-4 flex items-center gap-2 bg-white text-black font-bold px-6 py-3 rounded-xl text-sm hover:bg-white/90 disabled:opacity-50">
            <Check size={15} /> {salvando ? "Salvando..." : "Criar cupom"}
          </button>
        </div>
      )}

      {cupons.length === 0 ? (
        <p className="text-white/40">Nenhum cupom cadastrado.</p>
      ) : (
        <div className="flex flex-col gap-3">
          {cupons.map(c => (
            <div key={c.id} className="bg-zinc-900 rounded-2xl border border-white/10 p-5">
              {editandoId === c.id ? (
                <div>
                  <p className="text-white font-bold mb-4 text-sm">Editando cupom</p>
                  <CupomForm form={editForm} setForm={setEditForm} produtos={produtos} />
                  <div className="flex gap-2 mt-4">
                    <button onClick={() => salvarEdicao(c.id)} className="flex items-center gap-1.5 bg-green-600 hover:bg-green-500 text-white font-bold px-4 py-2 rounded-lg text-sm">
                      <Check size={14} /> Salvar
                    </button>
                    <button onClick={() => setEditandoId(null)} className="flex items-center gap-1.5 bg-white/10 hover:bg-white/20 text-white font-bold px-4 py-2 rounded-lg text-sm">
                      <X size={14} /> Cancelar
                    </button>
                  </div>
                </div>
              ) : (
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-white font-black text-lg tracking-wider">{c.codigo}</p>
                    <p className="text-green-400 font-bold text-sm">- R$ {(c.desconto_reais || 0).toFixed(2).replace(".", ",")}</p>
                    <p className="text-white/40 text-xs mt-1">{getProdutoNome(c.produto_id)}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <button onClick={() => iniciarEdicao(c)} className="flex items-center gap-1 bg-white/10 hover:bg-white/20 text-white text-xs font-bold px-3 py-2 rounded-lg">
                      <Pencil size={12} /> Editar
                    </button>
                    <button onClick={() => handleDelete(c.id)} className="flex items-center gap-1 bg-red-500/20 hover:bg-red-500/40 text-red-400 text-xs font-bold px-3 py-2 rounded-lg">
                      <Trash2 size={12} /> Remover
                    </button>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function CupomForm({ form, setForm, produtos }) {
  return (
    <div className="flex flex-col gap-4">
      <div>
        <label className="text-white/50 text-xs mb-1 block">Código do cupom *</label>
        <input type="text" placeholder="ex: DESCONTO20" value={form.codigo}
          onChange={e => setForm(p => ({ ...p, codigo: e.target.value.toUpperCase() }))}
          className="w-full bg-white/10 text-white placeholder-white/30 rounded-lg px-4 py-3 text-sm outline-none focus:bg-white/15" />
      </div>
      <div>
        <label className="text-white/50 text-xs mb-1 block">Desconto em R$ *</label>
        <input type="number" placeholder="ex: 20" value={form.desconto_reais}
          onChange={e => setForm(p => ({ ...p, desconto_reais: e.target.value }))}
          className="w-full bg-white/10 text-white placeholder-white/30 rounded-lg px-4 py-3 text-sm outline-none focus:bg-white/15" />
      </div>
      <div>
        <label className="text-white/50 text-xs mb-1 block">Produto (deixe vazio para todos)</label>
        <select value={form.produto_id} onChange={e => setForm(p => ({ ...p, produto_id: e.target.value }))}
          className="w-full bg-white/10 text-white rounded-lg px-4 py-3 text-sm outline-none focus:bg-white/15">
          <option value="">🌐 Todos os produtos</option>
          {produtos.map(p => (
            <option key={p.id} value={p.id}>{p.nome} — R$ {(p.preco || 0).toFixed(2).replace(".", ",")}</option>
          ))}
        </select>
      </div>
    </div>
  );
}