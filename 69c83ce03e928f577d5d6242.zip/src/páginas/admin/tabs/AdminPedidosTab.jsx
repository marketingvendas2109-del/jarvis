const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useEffect, useState } from "react";

import { Trash2 } from "lucide-react";

const STATUS_LABELS = { aguardando: "Aguardando", pago: "Pago", enviado: "Enviado" };
const ENTREGA_LABELS = { uber_moto: "🛵 Uber Moto", metro: "🚇 Metrô", casa: "🏠 Em casa", correios: "📮 Correios" };
const STATUS_COLORS = {
  aguardando: "bg-yellow-500/20 text-yellow-400",
  pago: "bg-green-500/20 text-green-400",
  enviado: "bg-blue-500/20 text-blue-400",
};

export default function AdminPedidosTab() {
  const [pedidos, setPedidos] = useState([]);
  const [loading, setLoading] = useState(true);
  const [imgModal, setImgModal] = useState(null);
  const [selecionados, setSelecionados] = useState([]);
  const [confirmando, setConfirmando] = useState(false);
  const [excluindo, setExcluindo] = useState(false);
  const [feedback, setFeedback] = useState("");

  useEffect(() => {
    db.entities.Pedido.list("-created_date", 200)
      .then(data => { setPedidos(data); setSelecionados([]); })
      .finally(() => setLoading(false));
  }, []);

  const mostrarFeedback = (msg) => {
    setFeedback(msg);
    setTimeout(() => setFeedback(""), 3000);
  };

  const toggleSelecionado = (id) => setSelecionados(prev =>
    prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]