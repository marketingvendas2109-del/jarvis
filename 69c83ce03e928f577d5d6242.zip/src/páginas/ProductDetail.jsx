const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState, useEffect } from "react";
import { useParams, Link, useNavigate } from "react-router-dom";
import { ArrowLeft, Copy, Check, Truck, Shield, RotateCcw, Share2 } from "lucide-react";

import GaleriaFotos from "@/components/GaleriaFotos";
import { resolveImageUrl } from "@/lib/imageUrl";

export default function ProductDetail({ onAddToCart }) {
  const { id } = useParams();
  const navigate = useNavigate();
  const [produto, setProduto] = useState(null);
  const [loading, setLoading] = useState(true);
  const [added, setAdded] = useState(false);
  const [copied, setCopied] = useState(false);
  const [tamanhoEscolhido, setTamanhoEscolhido] = useState("");
  const [variacaoSel, setVariacaoSel] = useState(null);

  const copyId = () => {
    navigator.clipboard.writeText(produto.id);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  useEffect(() => {
    window.scrollTo(0, 0);
    db.entities.Produto.filter({ id }).then(res => {
      setProduto(res[0] || null);
      setLoading(false);
    });
  }, [id]);

  if (loading) return (
    <div className="min-h-screen bg-background flex items-center justify-center">
      <div className="w-8 h-8 border-4 border-ink/15 border-t-ink rounded-full animate-spin" />