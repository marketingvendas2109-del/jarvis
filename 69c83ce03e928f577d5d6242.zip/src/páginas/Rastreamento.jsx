import AnimatedPage from "../components/AnimatedPage";
import { ArrowLeft } from "lucide-react";
import { Link } from "react-router-dom";

export default function Rastreamento() {
  return (
    <AnimatedPage>
      <div className="bg-black min-h-screen px-4 py-10">
        <div className="max-w-md mx-auto">
          <Link to="/" className="flex items-center gap-2 text-white/40 hover:text-white text-sm mb-8 transition-colors">
            <ArrowLeft size={14} /> Voltar
          </Link>

          <div className="text-center mb-12">
            <p className="text-white/40 text-xs uppercase tracking-widest mb-1">Acompanhe seu pedido</p>
            <h1 className="text-white font-black text-3xl">Rastreamento</h1>
          </div>

          <div className="mt-12 bg-white/5 border border-white/10 rounded-xl p-6 text-center">
            <p className="text-white/50 text-sm leading-relaxed">
              Após finalizar seu pedido, entraremos em contato pelo WhatsApp com todas as informações de entrega e acompanhamento.
            </p>
          </div>
        </div>
      </div>
    </AnimatedPage>
  );
}