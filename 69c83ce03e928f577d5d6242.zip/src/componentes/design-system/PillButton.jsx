import { motion } from "framer-motion";

/**
 * PillButton — the ONLY button style in the system.
 * Obsidian fill, white text, 30px radius, no shadow, no border.
 * Variant "inverse" = white fill + Obsidian text (for dark heroes).
 */
export default function PillButton({
  children,
  onClick,
  variant = "default",
  className = "",
  ...props
}) {
  const base =
    "inline-flex items-center justify-center font-medium text-[16px] leading-[1.5] " +
    "rounded-[30px] py-[6px] px-[8px] border-none cursor-pointer transition-opacity duration-150 hover:opacity-85 " +
    "disabled:opacity-40 disabled:cursor-not-allowed";

  const styles =
    variant === "inverse"
      ? "bg-white text-[#111111]"
      : "bg-[#111111] text-white";

  return (
    <motion.button
      whileTap={{ scale: 0.97 }}
      onClick={onClick}
      className={`${base} ${styles} ${className}`}
      {...props}
    >
      {children}
    </motion.button>
  );