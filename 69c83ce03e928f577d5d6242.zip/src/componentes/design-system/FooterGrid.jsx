/**
 * FooterGrid — white bg, four columns, no dividers, no social icons.
 * Headers: Display Medium 16-20px Obsidian. Links: Text 16px Steel.
 */
export default function FooterGrid({ columns = [], region = "Brasil" }) {
  return (
    <footer className="w-full bg-white border-t border-[#e5e5e5]">
      <div className="max-w-[1440px] mx-auto px-[16px] py-[48px]">
        {/* Region selector */}
        <div className="flex justify-end mb-[24px]">
          <span className="text-[#111111] text-[16px] font-medium cursor-pointer">
            🌐 {region}
          </span>
        </div>

        {/* Link columns */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-[24px]">
          {columns.map((col) => (
            <div key={col.title} className="flex flex-col gap-[12px]">
              <h4 className="text-[#111111] text-[16px] font-medium leading-[1.5]">
                {col.title}
              </h4>
              {col.links?.map((link) => (
                <span
                  key={link.label}
                  onClick={link.onClick}
                  className="text-[#707072] text-[16px] font-normal leading-[1.75] cursor-pointer hover:text-[#111111] transition-colors"
                >
                  {link.label}
                </span>
              ))}
            </div>
          ))}
        </div>