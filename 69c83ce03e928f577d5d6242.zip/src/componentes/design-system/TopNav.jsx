import { Search, Heart, ShoppingBag } from "lucide-react";

/**
 * TopNav — two-tier transparent nav on white.
 * Utility bar (thin, 12px) + main nav row (logo, categories, search, icons).
 * NO background fill, NO shadow, NO sticky blur.
 */
export default function TopNav({ logo = "ZENON", categories = [], onSearch, cartCount = 0 }) {
  return (
    <header className="w-full bg-transparent border-b border-[#e5e5e5]">
      {/* Utility bar */}
      <div className="flex items-center justify-end gap-[16px] px-[16px] py-[4px]">
        <span className="text-[#111111] text-[12px] font-normal cursor-pointer hover:opacity-70">
          Ajuda
        </span>
        <span className="text-[#707072] text-[12px]">|</span>
        <span className="text-[#111111] text-[12px] font-normal cursor-pointer hover:opacity-70">
          Entrar
        </span>
      </div>

      {/* Main nav */}
      <div className="flex items-center justify-between px-[16px] py-[8px]">
        <span className="text-[#111111] font-medium text-[20px] tracking-tight cursor-pointer">
          {logo}
        </span>

        <nav className="hidden md:flex items-center gap-[24px]">
          {categories.map((cat) => (
            <span
              key={cat.label}
              onClick={cat.onClick}
              className="text-[#111111] text-[16px] font-medium cursor-pointer hover:opacity-70 transition-opacity"
            >