import { Search } from "lucide-react";
import { motion } from "framer-motion";

/**
 * SearchField — Soft Mist fill, 24px radius, no border.
 * Search icon in Steel, placeholder in Obsidian.
 */
export default function SearchField({ value, onChange, placeholder = "Buscar" }) {
  return (
    <motion.div
      whileTap={{ scale: 0.98 }}
      className="flex items-center gap-[8px] bg-[#f5f5f5] rounded-[24px] py-[6px] px-[8px] border-none"
    >
      <Search size={16} className="text-[#707072] flex-shrink-0" />
      <input
        type="text"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="bg-transparent text-[#111111] text-[16px] font-normal outline-none w-full placeholder:text-[#111111]"
      />
    </motion.div>
  );
}