import PillButton from "./PillButton";

/**
 * CategoryHeroCard — full-bleed product photography tile.
 * No border, no radius, no shadow. Image fills edge-to-edge.
 * Text overlaid bottom-left in white.
 */
export default function CategoryHeroCard({ image, label, headline, ctaLabel, onCtaClick }) {
  return (
    <div
      className="relative w-full overflow-hidden cursor-pointer rounded-none border-none shadow-none"
      style={{ aspectRatio: "1 / 1" }}
    >
      <img
        src={image}
        alt={headline}
        className="absolute inset-0 w-full h-full object-cover"
      />
      <div className="absolute bottom-0 left-0 p-[24px] flex flex-col gap-[12px]">
        <span className="text-white text-[16px] font-normal leading-[1.5]">
          {label}
        </span>
        <h3 className="text-white text-[24px] font-medium leading-[1.2]">
          {headline}
        </h3>
        {ctaLabel && (
          <PillButton variant="inverse" onClick={onCtaClick} className="self-start">
            {ctaLabel}
          </PillButton>
        )}
      </div>
    </div>
  );
}