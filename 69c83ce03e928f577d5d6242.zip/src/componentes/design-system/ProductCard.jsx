import { motion } from "framer-motion";

/**
 * ProductCard — white bg, no border, no radius, no shadow.
 * Image centered upper portion. Product name as small pill overlay.
 * NO price, NO description, NO CTAs inside the card.
 */
export default function ProductCard({ product, onClick }) {
  return (
    <motion.div
      whileHover={{ opacity: 0.85 }}
      onClick={onClick}
      className="bg-white rounded-none border-none shadow-none cursor-pointer flex flex-col"
    >
      <div className="aspect-square bg-[#f5f5f5] overflow-hidden">
        {product.image ? (
          <img
            src={product.image}
            alt={product.name}
            className="w-full h-full object-cover"
          />
        ) : (
          <div className="w-full h-full" />
        )}
      </div>
      <div className="pt-[12px]">
        <span className="inline-block bg-[#111111] text-white text-[14px] font-medium rounded-[30px] py-[4px] px-[10px]">
          {product.name}
        </span>
      </div>
    </motion.div>
  );
}