import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { MessageCircle } from "lucide-react";

export default function JaoButton() {
  const navigate = useNavigate();
  return (
    <motion.button
      initial={{ opacity: 0, scale: 0.5 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ delay: 0.4, type: "spring", stiffness: 200, damping: 15 }}
      whileHover={{ scale: 1.1 }}
      whileTap={{ scale: 0.9 }}
      onClick={() => navigate("/jao")}
      className="fixed bottom-5 right-4 z-50 bg-[#111111] text-white w-14 h-14 rounded-[30px] flex items-center justify-center hover:opacity-85 transition-opacity"
      title="Falar com Jão"
    >
      <MessageCircle size={24} strokeWidth={1.5} />
    </motion.button>
  );
}