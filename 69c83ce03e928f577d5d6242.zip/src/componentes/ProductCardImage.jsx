import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ShoppingBag } from "lucide-react";
import { resolveImageUrl } from "@/lib/imageUrl";

export default function ProductCardImage({ produto, className = "" }) {
  const fotos = [
    ...(produto.imagem ? [produto.imagem] : []),
    ...((produto.imagens || []).filter(f => f && f !== produto.imagem)),
  ];

  const [idx, setIdx] = useState(0);

  useEffect(() => {
    if (fotos.length <= 1) return;
    const t = setInterval(() => {
      setIdx(i => (i + 1) % fotos.length);
    }, 3000);
    return () => clearInterval(t);
  }, [fotos.length]);

  if (fotos.length === 0) {
    return (
      <div className={`${className} bg-muted flex items-center justify-center`}>
        <ShoppingBag size={32} className="text-steel" strokeWidth={1.5} />
      </div>
    );
  }

  return (
    <div className={`${className} relative overflow-hidden bg-muted`}>
      <AnimatePresence mode="wait">
        <motion.img
          key={idx}