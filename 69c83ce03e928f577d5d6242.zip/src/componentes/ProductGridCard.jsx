import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { ShoppingBag, Copy, Check } from "lucide-react";
import ProductCardImage from "./ProductCardImage";

export default function ProductGridCard({ produto, onComprar, onAddToCart, showCopyId = false }) {
  const navigate = useNavigate();
  const [copied, setCopied] = useState(false);
  const preco = produto.preco || 0;
  const parcela = preco / 3;

  const go = () => navigate(`/produto/${produto.id}`);

  const copyId = (e) => {
    e.stopPropagation();
    navigator.clipboard.writeText(produto.id);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="flex flex-col">
      <div className="relative aspect-square overflow-hidden bg-mist cursor-pointer" onClick={go}>
        <ProductCardImage produto={produto} className="aspect-square" />
        {showCopyId && (
          <button
            onClick={copyId}
            title="Copiar ID do produto"
            className="absolute bottom-2 right-2 flex items-center gap-1 bg-white/90 px-2 py-1 text-[10px] font-semibold uppercase tracking-wider text-ink hover:bg-white transition-colors"
          >
            {copied ? <Check size={10} strokeWidth={2} /> : <Copy size={10} strokeWidth={2} />}
            {copied ? "Copiado" : "ID"}
          </button>
        )}