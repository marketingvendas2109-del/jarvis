import { useState } from "react";
import { Link } from "react-router-dom";
import { Instagram, Truck, RefreshCw, Shield, Headphones } from "lucide-react";

export default function Footer() {
  const [email, setEmail] = useState("");
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = (e) => {
    e.preventDefault();
    if (email) {
      setSubscribed(true);
      setEmail("");
    }
  };

  const services = [
    { icon: Truck, title: "Frete Grátis", desc: "Em pedidos acima de R$ 200" },
    { icon: RefreshCw, title: "Trocas Fáceis", desc: "Até 7 dias após a compra" },
    { icon: Shield, title: "Pagamento Seguro", desc: "PIX protegido" },
    { icon: Headphones, title: "Suporte", desc: "Atendimento via WhatsApp" },
  ];

  const columns = [
    {
      title: "Loja",
      links: [
        { label: "Todos os produtos", to: "/produtos" },
        { label: "Kits Dry Fit", to: "/produtos" },
        { label: "Bonés", to: "/produtos" },
        { label: "Acessórios", to: "/produtos" },
      ],
    },
    {