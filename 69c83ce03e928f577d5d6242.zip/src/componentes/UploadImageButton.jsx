const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState, useRef } from "react";
import { Upload, Loader2, Camera, FolderOpen, X } from "lucide-react";

/**
 * Botão de upload inteligente:
 * - Desktop: abre seletor de arquivo direto
 * - Mobile: exibe modal perguntando "Galeria" ou "Câmera"
 */
export default function UploadImageButton({ label, currentImage, onUploaded, rounded = false }) {
  const [uploading, setUploading] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const fileInputRef = useRef(null);
  const cameraInputRef = useRef(null);

  const isMobile = () => /Mobi|Android|iPhone|iPad|iPod/i.test(navigator.userAgent);

  const handleClick = () => {
    if (isMobile()) {
      setShowModal(true);
    } else {
      fileInputRef.current?.click();
    }
  };

  const doUpload = async (file) => {
    if (!file) return;
    setUploading(true);
    setShowModal(false);
    const { file_url } = await db.integrations.Core.UploadFile({ file });
    onUploaded(file_url);
    setUploading(false);
  };