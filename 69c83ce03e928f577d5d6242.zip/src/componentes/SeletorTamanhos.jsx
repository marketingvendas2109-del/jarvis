const TAMANHOS_PADRAO = ["PP", "P", "M", "G", "GG", "XG", "Único"];

export default function SeletorTamanhos({ tamanhos = [], onChange }) {
  const toggle = (t) => {
    if (tamanhos.includes(t)) {
      onChange(tamanhos.filter(x => x !== t));
    } else {
      onChange([...tamanhos, t]);
    }
  };

  return (
    <div>
      <p className="text-white/50 text-xs mb-2">Clique para ativar/desativar cada tamanho</p>
      <div className="flex flex-wrap gap-2">
        {TAMANHOS_PADRAO.map(t => (
          <button
            key={t}
            type="button"
            onClick={() => toggle(t)}
            className={`px-3 py-1.5 rounded-lg text-sm font-bold border transition-all ${
              tamanhos.includes(t)
                ? "bg-white text-black border-white"
                : "bg-white/5 text-white/50 border-white/15 hover:border-white/40"
            }`}
          >
            {t}
          </button>
        ))}
      </div>
      {tamanhos.length > 0 && (
        <p className="text-white/40 text-xs mt-2">Selecionados: {tamanhos.join(", ")}</p>
      )}
    </div>