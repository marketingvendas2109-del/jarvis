import { AuroraBackground } from "@/components/ui/aurora-background";

// Site-wide aurora backdrop: stays fixed behind every page while content scrolls.
export default function AuroraSiteBackground() {
  return (
    <div aria-hidden="true" className="fixed inset-0 -z-10 pointer-events-none overflow-hidden">
      <AuroraBackground />
    </div>
  );
}