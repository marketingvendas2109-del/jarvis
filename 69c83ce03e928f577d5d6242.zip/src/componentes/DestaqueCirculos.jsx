import { useNavigate } from "react-router-dom";
import { resolveImageUrl } from "@/lib/imageUrl";

const DESTAQUES = [
  { key: "camisa", label: "Camisas", emoji: "👕", fallback: "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=200&h=200&fit=crop" },
  { key: "kit", label: "Kits", emoji: "🎁", fallback: "https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=200&h=200&fit=crop" },
  { key: "bone", label: "Bonés", emoji: "🧢", fallback: "https://images.unsplash.com/photo-1588850561407-ed78c282e89b?w=200&h=200&fit=crop" },
  { key: "cordinha", label: "Cordinhas", emoji: "📿", fallback: "https://images.unsplash.com/photo-1611652022419-a9419f74343d?w=200&h=200&fit=crop" },
  { key: "relogio", label: "Relógios", emoji: "⌚", fallback: "https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=200&h=200&fit=crop" },
];

export default function DestaqueCirculos({ produtos }) {
  const navigate = useNavigate();

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="flex items-center justify-center gap-6 md:gap-10 overflow-x-auto pb-2 scrollbar-hide">
        {DESTAQUES.map(d => {
          const produto = produtos.find(p => p.destaque === d.key);
          const imgSrc = produto?.imagem_destaque
            ? resolveImageUrl(produto.imagem_destaque)
            : produto?.imagem
            ? resolveImageUrl(produto.imagem)
            : d.fallback;

          return (
            <button
              key={d.key}
              onClick={() => navigate(`/produtos?destaque=${d.key}`)}
              className="flex flex-col items-center gap-2 flex-shrink-0 group"
            >
              <div className="w-20 h-20 md:w-24 md:h-24 rounded-full overflow-hidden border-2 border-white/20 group-hover:border-white transition-all duration-300 bg-zinc-900">
                <img
                  src={imgSrc}