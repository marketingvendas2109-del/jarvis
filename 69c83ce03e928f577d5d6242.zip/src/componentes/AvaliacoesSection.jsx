const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { Star, Quote } from "lucide-react";

function StarRating({ nota }) {
  return (
    <div className="flex gap-0.5">
      {[1, 2, 3, 4, 5].map(i => (
        <Star
          key={i}
          size={14}
          strokeWidth={1.5}
          className={i <= nota ? "text-[#111111] fill-[#111111]" : "text-[#e5e5e5]"}
        />
      ))}
    </div>
  );
}

export default function AvaliacoesSection() {
  const [avaliacoes, setAvaliacoes] = useState([]);

  useEffect(() => {
    db.entities.Avaliacao.filter({ ativo: true }).then(data => {
      setAvaliacoes(data.sort(() => Math.random() - 0.5).slice(0, 8));
    });
  }, []);

  if (avaliacoes.length === 0) return null;

  return (
    <section className="max-w-7xl mx-auto px-4 pb-16">
      <div className="mb-8">