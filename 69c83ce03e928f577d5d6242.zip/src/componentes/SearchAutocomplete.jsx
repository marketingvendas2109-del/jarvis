const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { Search, X, Package } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

import { resolveImageUrl } from "@/lib/imageUrl";

/**
 * Autocomplete de produtos:
 * - Sugere conforme o cliente digita
 * - Destaca o termo pesquisado no nome
 * - Navegação por teclado (↑ ↓ Enter Esc)
 * - Ordena por relevância (match no início > meio)
 */
export default function SearchAutocomplete({ open, onClose }) {
  const [query, setQuery] = useState("");
  const [results, setResults] = useState([]);
  const [allProdutos, setAllProdutos] = useState([]);
  const [activeIndex, setActiveIndex] = useState(-1);
  const inputRef = useRef(null);
  const listRef = useRef(null);
  const navigate = useNavigate();

  useEffect(() => {
    db.entities.Produto.list("-created_date", 200).then(setAllProdutos);
  }, []);

  useEffect(() => {
    if (open) {
      setTimeout(() => inputRef.current?.focus(), 100);
    } else {
      setQuery("");
      setResults([]);
      setActiveIndex(-1);