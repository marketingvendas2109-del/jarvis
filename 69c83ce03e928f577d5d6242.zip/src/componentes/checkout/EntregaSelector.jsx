import { Bike, TrainFront, Home, MessageCircle } from "lucide-react";
import SectionHeading from "./SectionHeading";
import CheckoutInput from "./CheckoutInput";

const OPCOES = [
  { id: "uber_moto", Icone: Bike, titulo: "Uber Moto", descricao: "Retirada no local" },
  { id: "metro", Icone: TrainFront, titulo: "Estação de metrô", descricao: "Combinar estação e taxa via WhatsApp" },
  { id: "casa", Icone: Home, titulo: "Entrega em casa", descricao: "Recife e região" },
];

export default function EntregaSelector({ tipoEntrega, onSelecionar, erro, endereco, onEndereco, erros }) {
  return (
    <section className="border-t border-ink/10 pt-8">
      <SectionHeading step="02" title="Entrega" />

      {erro && <p className="text-red-600 text-[11px] mb-3">{erro}</p>}

      <div className="border border-ink/20 divide-y divide-ink/10">
        {OPCOES.map(({ id, Icone, titulo, descricao }) => {
          const ativo = tipoEntrega === id;
          return (
            <button
              key={id}
              type="button"
              onClick={() => onSelecionar(id)}
              className={`w-full flex items-center gap-3.5 px-4 py-4 text-left transition-colors ${ativo ? "bg-mist" : "hover:bg-mist"}`}
            >
              <Icone size={18} strokeWidth={1.6} className={ativo ? "text-ink" : "text-steel"} />
              <div className="flex-1 min-w-0">
                <p className="text-ink font-semibold text-[13px]">{titulo}</p>
                <p className="text-steel text-[11px] mt-0.5">{descricao}</p>
              </div>
              <span className={`w-4 h-4 rounded-full border flex items-center justify-center flex-shrink-0 ${ativo ? "border-ink" : "border-ink/30"}`}>
                {ativo && <span className="w-2 h-2 rounded-full bg-ink" />}