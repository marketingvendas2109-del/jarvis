import { ShieldCheck, Truck, RotateCcw, Tag, X, CheckCheck } from "lucide-react";

export default function CheckoutSummary({
  produtoNome,
  produtoImagem,
  precoBase,
  valorEntrega,
  desconto,
  cupomAplicado,
  cupomInput,
  onCupomInput,
  onAplicarCupom,
  onRemoverCupom,
  cupomErro,
  cupomLoading,
  totalFinal,
}) {
  const brl = (v) => `R$ ${v.toFixed(2).replace(".", ",")}`;

  return (
    <div className="border border-ink/20">
      <div className="px-4 sm:px-5 py-3 border-b border-ink/10">
        <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-ink">Resumo do pedido</p>
      </div>

      <div className="px-4 sm:px-5 py-4 flex items-center gap-3.5 border-b border-ink/10">
        {produtoImagem ? (
          <img src={produtoImagem} alt={produtoNome} className="w-16 h-16 object-cover bg-mist flex-shrink-0" />
        ) : (
          <div className="w-16 h-16 bg-mist flex-shrink-0" />
        )}
        <div className="flex-1 min-w-0">
          <p className="text-ink font-semibold text-[13px] leading-snug line-clamp-2">{produtoNome}</p>
          <p className="text-steel text-[11px] mt-1">Quantidade 1</p>