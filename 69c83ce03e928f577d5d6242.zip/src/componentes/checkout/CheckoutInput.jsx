import { cn } from "@/lib/utils";

export default function CheckoutInput({ error, hint, className, ...props }) {
  return (
    <div className={className}>
      <input
        {...props}
        className={cn(
          "w-full bg-background text-ink placeholder-steel px-4 py-3 text-sm outline-none border transition-colors",
          error ? "border-red-500" : "border-ink/20 focus:border-ink"
        )}
      />
      {error ? (
        <p className="text-red-600 text-[11px] mt-1.5">{error}</p>
      ) : hint ? (
        <p className="text-steel text-[11px] mt-1.5">{hint}</p>
      ) : null}
    </div>
  );
}