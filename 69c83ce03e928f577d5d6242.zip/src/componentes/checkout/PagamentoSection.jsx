import { Copy, CheckCheck, Upload, X, Banknote, Calculator, MessageCircle, AlertTriangle } from "lucide-react";
import SectionHeading from "./SectionHeading";

export default function PagamentoSection({
  pixKey,
  pixNome,
  metodoPagamento,
  onMetodo,
  parcelado,
  onParcelado,
  parcelas,
  onParcelas,
  valorParcela,
  totalFinal,
  copiado,
  onCopiarPix,
  comprovantePreview,
  onComprovante,
  onRemoverComprovante,
  erroComprovante,
}) {
  const brl = (v) => `R$ ${v.toFixed(2).replace(".", ",")}`;

  return (
    <section className="border-t border-ink/10 pt-8">
      <SectionHeading step="03" title="Pagamento" />

      <div className="grid grid-cols-2 gap-2 mb-5">
        {[["pix", "PIX"], ["dinheiro", "Dinheiro"]].map(([id, label]) => (
          <button
            key={id}
            type="button"
            onClick={() => onMetodo(id)}
            className={`py-3 text-[10px] font-bold uppercase tracking-[0.16em] border transition-colors ${