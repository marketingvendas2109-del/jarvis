const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState, useRef } from "react";
import { X, Images, Camera, Loader2, FolderOpen } from "lucide-react";

export default function UploadMultiplasImagens({ imagens = [], onChange }) {
  const [uploading, setUploading] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const galeriaRef = useRef(null);
  const cameraRef = useRef(null);

  const isMobile = () => /Mobi|Android|iPhone|iPad|iPod/i.test(navigator.userAgent);

  const handleClick = () => {
    if (isMobile()) {
      setShowModal(true);
    } else {
      galeriaRef.current?.click();
    }
  };

  const handleFiles = async (files) => {
    if (!files || files.length === 0) return;
    setUploading(true);
    setShowModal(false);
    const arr = Array.from(files);
    const urls = [];
    for (const file of arr) {
      const { file_url } = await db.integrations.Core.UploadFile({ file });
      urls.push(file_url);
    }
    onChange([...imagens, ...urls]);
    setUploading(false);
  };